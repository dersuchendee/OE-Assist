# OntoEval
ontology evaluation prototpye